%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  ToyModel-Chap7-dataForecasting.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOY MODEL for data forecasting in LiDAR experiments %%%
% %%%
%u(x,t)=(ax^3+bx^2+cx)*(f*sin(omega1*t)+g*cos(omega2*t))%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
close all

%% Set parameters for spatial and temporal discretization
% # Spatial points
nx=100
% # Temporal points
nt=1000
% Spatial dimension of the domain
xf=10
% Final time
tf=200
%% Set frequencies
omega1=2*pi/25
omega2=sqrt(5)
%% Set spatial and temporal coefficients in the toy model
a=2e-3
b=8e-2
c=1
f=2
g=0.25
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Create mesh
x=[0:xf/(nx-1):xf];
t=[0:tf/(nt-1):tf];
[X T]=meshgrid(0:xf/(nx-1):xf,0:tf/(nt-1):tf);
%% Create Toy Model: u(x,t)=
% (ax^3+bx^2+cx)*(f*sin(omega1*t)+g*cos(omega2*t))
for i=1:nx
for j=1:nt
u(i,j)=(a*x(i)^3+b*x(i)^2+c*x(i))*(f*sin(omega1*t(j))+g*cos(omega2*t(j)));
end
end
%% Plot TM
figure1 = figure;
colormap(jet);
axes1 = axes('Parent',figure1);
hold(axes1,'on');
pcolor(X,T,u')
xlabel('x')
ylabel('t')
box(axes1,'on');
set(axes1,'FontSize',18);
colorbar(axes1);
shading('interp')
colormap(jet)
%% Save TM
V_TM=u;
Time=t;
save V_TM_Chap7_LiDAR.mat V_TM
save Time.mat Time
save X.mat x