clc;clear all;close all

f1 = 50;
fs = 6400;
T  = 0.2;
n = fs*T;
t = (0:n-1)/fs;
m = length(t);
dt = 1/((fs/f1)*f1); %1/fs;


% x = (1*cos(2*pi*f1*t+(-1.488)))+((0.77)*cos(2*pi*3*f1*t+(1.560)))+((0.56)*cos(2*pi*5*f1*t+(-1.589)))+....
%    ((0.32)*cos(2*pi*7*f1*t+(1.545)))+((0.12)*cos(2*pi*9.46*f1*t+(-1.606)))+((0.06)*cos(2*pi*13*f1*t+(1.523)))+.....
%     ((0.06)*cos(2*pi*15.5*f1*t+(-1.632)))+((0.03)*cos(2*pi*17*f1*t+(1.4945)))+((0.03)*cos(2*pi*23*f1*t+(1.616))); 

x = (1+0.05*cos(2*pi*8*t)+0.1*cos(2*pi*13*t)+0.07*cos(2*pi*20*t)).*cos(2*pi*60*t);
% x = awgn(x,50);

%% Number of snapshots: nsnap
nsnap=length(x);
V=x(1:nsnap);
Time = t;
%% DMD-d
d=300;
%% Tolerance DMD-d
varepsilon1=1e-10 ;%SVD
varepsilon=1e-3 ;%DMD 

[M N]=size(V);

if d>1
    [Vreconst,deltas,omegas,amplitude,modes] =DMDd_SIADS(d,V,Time,varepsilon1,varepsilon);
else
    [Vreconst,deltas,omegas,amplitude] =DMD1_SIADS(V,Time,varepsilon1,varepsilon);
end 

figure; plot(real(modes));
figure;plot(V);hold on; plot(real(Vreconst),'*');

fest = omegas/(2*pi);
amps = amplitude*2;

Est_out = [fest;amps]; % final estimated outputs

